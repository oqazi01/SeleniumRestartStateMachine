import boto3
import json

ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    try:
        instance_id = event['detail']['configuration']['metrics'][0]['metricStat']['metric']['dimensions']['InstanceId']
        print(f"Stopping EC2 instance: {instance_id}")
        # Stop the EC2 instance
        response = ec2.stop_instances(InstanceIds=[instance_id])
    
        return {'status': 'stopping', 'InstanceId': instance_id}
    except KeyError as e:
        return {'statusCode': 400,'body': json.dumps(f"Error: Missing key {e}")}
