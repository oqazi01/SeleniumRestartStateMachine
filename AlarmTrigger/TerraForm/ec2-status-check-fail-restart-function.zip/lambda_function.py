import boto3

ec2 = boto3.client('ec2')

def lambda_handler(event, context):
    instance_id = event['InstanceId']
    response = ec2.describe_instances(InstanceIds=[instance_id])
    try:
        instance_state = response['Reservations'][0]['Instances'][0]['State']['Name']
        print(f"Input Instance state: {instance_state}")
    except Exception as e:
        raise KeyError(f"state does not exist with following error: {e}")
    
    if instance_state=="stopped":
        ec2.start_instances(InstanceIds=[instance_id])
        print("Starting instance")
        return {'status': 'starting'}
        
    elif instance_state=="stopping":
        print("Still Stopping -> Wait AND Retry")
        return {'status': 'stopping'}
    elif not instance_state:
        print("State not available -> Wait AND Retry")
        return {'status': 'stopping'}
    
    elif instance_state=="running":
        print(" Warning! Should either be in stopped or stopping state")
        print("Attempting to stop again")
        return {'status': 'running'}
        
    else:
        print (f'unknown state: {instance_state}')
        return {'status': 'unknown state'}
        
    